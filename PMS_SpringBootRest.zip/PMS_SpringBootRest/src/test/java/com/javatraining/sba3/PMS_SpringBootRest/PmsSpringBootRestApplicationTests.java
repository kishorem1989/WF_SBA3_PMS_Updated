package com.javatraining.sba3.PMS_SpringBootRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PmsSpringBootRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
