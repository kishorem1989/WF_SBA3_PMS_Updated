package com.javatraining.sba3.PMS_SpringBootRest.Service;


import java.util.List;

import com.javatraining.sba3.PMS_SpringBootRest.DTO.CompanyOutputDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.InvestorProfileDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.StockDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.UserOutputDTO;

public interface InvestorService 
{
	public InvestorProfileDTO savePurchaseTransaction(InvestorProfileDTO investorProfileDTO,CompanyOutputDTO companyOutputDTO,StockDTO stockDto);
	public InvestorProfileDTO saveSellingTransaction(InvestorProfileDTO investorProfileDTO,CompanyOutputDTO companyOutputDTO,StockDTO stockDto);
	public List<InvestorProfileDTO> findEachCompanyTitleForPurchasedShares();
	public List<InvestorProfileDTO> findByCompanyTitle(String companyTitle);
	public Integer findAvailableShareCountForEachCompany(String companyTitle);
	public List<InvestorProfileDTO> fetchAllRecords();
	
	public Double getCurrentPortfolioValue();
	public Double getAmountInvestedTillDate();
	public Double getAmountEarnedTillDate();
}
