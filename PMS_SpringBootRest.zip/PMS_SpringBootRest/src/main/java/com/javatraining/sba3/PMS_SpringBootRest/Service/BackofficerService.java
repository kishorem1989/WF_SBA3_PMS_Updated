
package com.javatraining.sba3.PMS_SpringBootRest.Service;
  
import java.util.List;

import javax.validation.Valid;

import com.javatraining.sba3.PMS_SpringBootRest.DTO.CommodityDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.CompanyInputDTO; 
import com.javatraining.sba3.PMS_SpringBootRest.DTO.CompanyOutputDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.StockDTO;
import com.javatraining.sba3.PMS_SpringBootRest.Entity.Stock; 
  
public interface BackofficerService 
 {
  
	  // COMPANY related 
	  public CompanyOutputDTO addCompany(CompanyInputDTO companyInputDTO);
	  public List<CompanyOutputDTO> fetchAllCompanies();
	  public CompanyOutputDTO updateCompany(String companyCode,CompanyInputDTO companyInputDTO); 
	  public CompanyOutputDTO fetchCompanyBasedOnCodeAndTitle(String companyCode,String companyTitle);
	  public CompanyOutputDTO fetchCompanyBasedOnCode(String companyCode);
	  public CompanyOutputDTO fetchCompanyBasedOnTitle(String companyTitle);
	  
	  // STOCK related
	  public StockDTO addStockDetails(StockDTO stockDto);
	  public List<StockDTO> fetchAllStocks();
	  public List<StockDTO> fetchStockBasedOnCompCode(String companyCode);
	 //public StockDTO fetchRecentStockBasedOnCompCode(String companyCode);
	  public List<StockDTO> findLatestStockRecordForEachCompanyTitle(String companytitle);
	  public List<StockDTO> fetchLatestStockDetailsForEachCompany();
	  
	  
	  // COMMODITIES related
	  public CommodityDTO addCommodityDetails(CommodityDTO commodityDTO);
	  public List<CommodityDTO> fetchAllCommodities();
	  public List<CommodityDTO> fetchCommodityBasedOnCommodityName(String commodityName);
	  
  
 }
 