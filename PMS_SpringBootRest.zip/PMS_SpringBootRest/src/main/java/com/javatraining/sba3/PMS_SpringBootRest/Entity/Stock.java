package com.javatraining.sba3.PMS_SpringBootRest.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Stock 
{
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)  
	 private Long stockId;
	
	 @Column(nullable = false) 
	 private String companycode;
	 
	 @Column(nullable = false) 
	 private String companytitle;
	 
	 @Column(nullable = false) 
	 private String stockexchange;
	 
	 @Column(nullable = false) 
	 private double currentprice;
	 
	 @Column(nullable = false) 
	 private String asofDateAndTime;
	 
	
	 public Stock()
	 {
		 
	 }


	public Long getStockId() {
		return stockId;
	}


	public void setStockId(Long stockId) {
		this.stockId = stockId;
	}


	public String getCompanycode() {
		return companycode;
	}


	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}


	public String getCompanytitle() {
		return companytitle;
	}


	public void setCompanytitle(String companytitle) {
		this.companytitle = companytitle;
	}


	public String getStockexchange() {
		return stockexchange;
	}


	public void setStockexchange(String stockexchange) {
		this.stockexchange = stockexchange;
	}


	public double getCurrentprice() {
		return currentprice;
	}


	public void setCurrentprice(double currentprice) {
		this.currentprice = currentprice;
	}


	public String getAsofDateAndTime() {
		return asofDateAndTime;
	}


	public void setAsofDateAndTime(String asofDateAndTime) {
		this.asofDateAndTime = asofDateAndTime;
	}
	 
	 
	 
}
