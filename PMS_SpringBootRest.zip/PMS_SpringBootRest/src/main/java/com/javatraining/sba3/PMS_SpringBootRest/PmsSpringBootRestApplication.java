package com.javatraining.sba3.PMS_SpringBootRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PmsSpringBootRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(PmsSpringBootRestApplication.class, args);
	}

}
