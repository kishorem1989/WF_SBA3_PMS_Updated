package com.javatraining.sba3.PMS_SpringBootRest.DTO;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class CompanyInputDTO
{
	
	 private String companycode;
	 
	 @NotNull(message = "Company Title is mandatory")
	 @NotBlank(message = "Company Title is mandatory")
	 private String companytitle;
	 
	 @NotNull(message = "Company operation is mandatory")
	 @NotBlank(message = "Company operation is mandatory")
	 private String operations; 
	 
	 @NotNull(message = "Share count is mandatory")
	 @Min(value=1,message = "share count must be greater than 1")
	 private int sharecount;
	 
	 @NotNull(message = "Open share price is mandatory")
	 @DecimalMin(value = "1.0",message="Open share price must be greater than 1")
	 private double openshareprice; 
	 
	 @NotNull(message = "Company sector is mandatory")
	 @NotBlank(message = "Company sector is mandatory")
	 private String sector;	
	 
	 
	 @NotNull(message = "Company turnover is mandatory")
	 @DecimalMin(value = "1.0",message="Company turnover must be greater than 1")
	 private double turnover;
	 
	
	// setters and getters
	 
	public String getCompanycode() {
		return companycode;
	}
	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}
	public String getCompanytitle() {
		return companytitle;
	}
	public void setCompanytitle(String companytitle) {
		this.companytitle = companytitle;
	}
	public String getOperations() {
		return operations;
	}
	public void setOperations(String operations) {
		this.operations = operations;
	}
	
	public int getSharecount() {
		return sharecount;
	}
	public void setSharecount(int sharecount) {
		this.sharecount = sharecount;
	}
	public double getOpenshareprice() {
		return openshareprice;
	}
	public void setOpenshareprice(double openshareprice) {
		this.openshareprice = openshareprice;
	}
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	
	public double getTurnover() {
		return turnover;
	}
	public void setTurnover(double turnover) {
		this.turnover = turnover;
	}
	 
	 
}
