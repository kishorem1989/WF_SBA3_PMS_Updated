package com.javatraining.sba3.PMS_SpringBootRest.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.javatraining.sba3.PMS_SpringBootRest.Entity.Commodities;
import com.javatraining.sba3.PMS_SpringBootRest.Entity.Stock;

@Component
public interface CommodityRepository extends JpaRepository<Commodities, Long>
{
	List<Commodities> findByCommodityname(String commodityname);
}
