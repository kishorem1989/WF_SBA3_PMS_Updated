package com.javatraining.sba3.PMS_SpringBootRest.Service;

import java.util.List;

import com.javatraining.sba3.PMS_SpringBootRest.DTO.UserInputDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.UserOutputDTO;

public interface UserService 
{
	// will be called by controller and these methods in turn will call method from  dao layer
	
	public UserOutputDTO addUser(UserInputDTO userInputDTO);
	public UserOutputDTO fetchBasedOnUserName(String username);
	public UserOutputDTO fetchBasedOnPAN(String pan);
	public UserOutputDTO fetchBasedOnUserNameAndPassword(String username,String password);

}
