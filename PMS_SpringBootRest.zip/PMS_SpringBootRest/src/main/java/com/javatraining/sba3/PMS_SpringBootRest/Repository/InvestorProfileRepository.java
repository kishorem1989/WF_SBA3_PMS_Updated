package com.javatraining.sba3.PMS_SpringBootRest.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import com.javatraining.sba3.PMS_SpringBootRest.Entity.InvestorProfile;


@Component
public interface InvestorProfileRepository extends JpaRepository<InvestorProfile, Long> 
{
	/////////////////// to get total amount invested/////////////////////////
	@Query(value = "SELECT IFNULL(sum(shareamount),0) FROM investor_profile where transaction_type='purchase'",nativeQuery = true)
	Double findAmountInvestedInShares();	
	
	/////////////////// to get total amount earned/////////////////////////
	@Query(value = "SELECT IFNULL(sum(shareamount),0) FROM investor_profile where transaction_type='sell'",nativeQuery = true)
	Double findAmountEarnedInShares();
	
	@Query(value = "SELECT * from investor_profile where transaction_type='purchase' group by companytitle order by companytitle asc",nativeQuery = true)
	List<InvestorProfile> findEachCompanyTitleForPurchasedShares();
	
	List<InvestorProfile> findByCompanytitle(String companytitle);
	
	@Query(value = "SELECT (select IFNULL(sum(sharecount),0) from investor_profile where transaction_type='purchase' and companytitle=?1) - (select IFNULL(sum(sharecount),0) from investor_profile where transaction_type='sell' and companytitle=?1)  AS difference",nativeQuery = true)
	Integer findAvailableShareCountForEachCompany(String companytitle);
	
	
	
	
}
