package com.javatraining.sba3.PMS_SpringBootRest.Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.javatraining.sba3.PMS_SpringBootRest.DTO.CompanyOutputDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.InvestorProfileDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.StockDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.UserOutputDTO;
import com.javatraining.sba3.PMS_SpringBootRest.Entity.InvestorProfile;
import com.javatraining.sba3.PMS_SpringBootRest.Repository.InvestorPortfolioWalletRepository;
import com.javatraining.sba3.PMS_SpringBootRest.Repository.InvestorProfileRepository;
import com.javatraining.sba3.PMS_SpringBootRest.Repository.RecentlyViewedCompaniesRepository;



@Component 
public class InvestorServiceImplementation implements InvestorService
{
	
	@Autowired //field based dependency 
	private InvestorProfileRepository investorProfileRepository;
	  
	@Autowired //field based dependency 
	private InvestorPortfolioWalletRepository investorPortfolioWalletRepository;
	  
	@Autowired //field based dependency 
	private RecentlyViewedCompaniesRepository recentlyViewedCompaniesRepository;

	
	public InvestorProfile investorProfileDTOToEntity(InvestorProfileDTO investorProfileDTO,CompanyOutputDTO companyOutputDTO,StockDTO stockDto)
	{
		InvestorProfile investorProfile = new InvestorProfile();
		investorProfile.setBrokerageAmount(investorProfileDTO.getBrokerageAmount()); // for sell 2% and for purchase 0.0
		investorProfile.setCompanycode(companyOutputDTO.getCompanycode());
		investorProfile.setCompanytitle(companyOutputDTO.getCompanytitle());
		investorProfile.setCurrencyType(investorProfileDTO.getCurrencyType()); //UI
		investorProfile.setShareamount(investorProfileDTO.getShareamount()); //UI
		investorProfile.setSharecount(investorProfileDTO.getSharecount()); // UI
		//********************************************
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss aa");  
		Date date = new Date(); 
		investorProfile.setTransactionDateAndTime(formatter.format(date).toString()); // system date and time for sell/purchase
		//********************************************
		investorProfile.setTransactionType(investorProfileDTO.getTransactionType());
		investorProfile.setUsername(investorProfileDTO.getUsername());
		investorProfile.setPurchasedStockPrice(stockDto.getCurrentprice());
		return investorProfile;
	}
	public InvestorProfileDTO investorProfileEntityToDTO(InvestorProfile investorProfile)
	{
		InvestorProfileDTO investorProfileDTO = new InvestorProfileDTO();
		investorProfileDTO.setBrokerageAmount(investorProfile.getBrokerageAmount());
		investorProfileDTO.setCompanycode(investorProfile.getCompanycode());
		investorProfileDTO.setCompanytitle(investorProfile.getCompanytitle());
		investorProfileDTO.setCurrencyType(investorProfile.getCurrencyType());
		investorProfileDTO.setShareamount(investorProfile.getShareamount());
		investorProfileDTO.setSharecount(investorProfile.getSharecount());
		investorProfileDTO.setTransactionDateAndTime(investorProfile.getTransactionDateAndTime());
		investorProfileDTO.setTransactionType(investorProfile.getTransactionType());
		investorProfileDTO.setUsername(investorProfile.getUsername());
		investorProfileDTO.setPurchasedStockPrice(investorProfile.getPurchasedStockPrice());
		return investorProfileDTO;
	}
	
	
	@Override
	public InvestorProfileDTO savePurchaseTransaction(InvestorProfileDTO investorProfileDTO,CompanyOutputDTO companyOutputDTO,StockDTO stockDto) 
	{
		InvestorProfile investorProfile = new InvestorProfile();
		
		//****************************
		investorProfileDTO.setBrokerageAmount(0.0);
		investorProfileDTO.setTransactionType("purchase");
		investorProfileDTO.setUsername("bhuvi5"); // look into - shud be dynamic
		//****************************
		investorProfile = this.investorProfileDTOToEntity(investorProfileDTO,companyOutputDTO,stockDto);
		InvestorProfile savedInvestorProfile = investorProfileRepository.save(investorProfile);
		InvestorProfileDTO savedInvestorProfileDTO = this.investorProfileEntityToDTO(savedInvestorProfile);
		return savedInvestorProfileDTO;
	}
	
	@Override
	public List<InvestorProfileDTO> findEachCompanyTitleForPurchasedShares()
	{
		List<InvestorProfileDTO> investorProfileDTOs = new ArrayList<InvestorProfileDTO>();
		List<InvestorProfile> investorProfiles = investorProfileRepository.findEachCompanyTitleForPurchasedShares();
		for(InvestorProfile eachInvestorProfile:investorProfiles)
		{
			InvestorProfileDTO investorProfileDTO = this.investorProfileEntityToDTO(eachInvestorProfile);
			investorProfileDTOs.add(investorProfileDTO);
		}
		return investorProfileDTOs;
	}
	
	
	@Override
	public List<InvestorProfileDTO> findByCompanyTitle(String companyTitle) 
	{
		List<InvestorProfileDTO> investorProfileDTOs = new ArrayList<InvestorProfileDTO>();
		List<InvestorProfile> investorProfiles = this.investorProfileRepository.findByCompanytitle(companyTitle);
		for(InvestorProfile eachInvestorProfile:investorProfiles)
		{
			InvestorProfileDTO investorProfileDTO = this.investorProfileEntityToDTO(eachInvestorProfile);
			investorProfileDTOs.add(investorProfileDTO);
		}
		return investorProfileDTOs;
	}
	
	
	@Override
	public Integer findAvailableShareCountForEachCompany(String companyTitle) 
	{
		Integer shareCountForCompany = this.investorProfileRepository.findAvailableShareCountForEachCompany(companyTitle);
		return shareCountForCompany;
	}
	
	
	@Override
	public InvestorProfileDTO saveSellingTransaction(InvestorProfileDTO investorProfileDTO,CompanyOutputDTO companyOutputDTO, StockDTO stockDto) 
	{
		InvestorProfile investorProfile = new InvestorProfile();
		
		//****************************
		investorProfileDTO.setTransactionType("sell");
		investorProfileDTO.setUsername("bhuvi5"); // look into - shud be dynamic
		//****************************
		investorProfile = this.investorProfileDTOToEntity(investorProfileDTO,companyOutputDTO,stockDto);
		InvestorProfile savedInvestorProfile = investorProfileRepository.save(investorProfile);
		InvestorProfileDTO savedInvestorProfileDTO = this.investorProfileEntityToDTO(savedInvestorProfile);
		return savedInvestorProfileDTO;
		
	}
	@Override
	public List<InvestorProfileDTO> fetchAllRecords() 
	{
		List<InvestorProfileDTO> investorProfileDTOs = new ArrayList<InvestorProfileDTO>();
		List<InvestorProfile> investorProfile = this.investorProfileRepository.findAll();
		for(InvestorProfile eachInvestorProfile:investorProfile)
		{
			InvestorProfileDTO investorProfileDTO = this.investorProfileEntityToDTO(eachInvestorProfile);
			investorProfileDTOs.add(investorProfileDTO);
		}
		return investorProfileDTOs;
	}
	@Override
	public Double getCurrentPortfolioValue() 
	{
		double amountEarnedInShares = this.investorProfileRepository.findAmountEarnedInShares();
		double amountInvestedInShares = this.investorProfileRepository.findAmountInvestedInShares();
		return (amountEarnedInShares+amountInvestedInShares);
	}
	@Override
	public Double getAmountInvestedTillDate() 
	{
		double amountInvestedInShares = this.investorProfileRepository.findAmountInvestedInShares();
		return (amountInvestedInShares);
	}
	
	@Override
	public Double getAmountEarnedTillDate() 
	{
		double amountEarnedInShares = this.investorProfileRepository.findAmountEarnedInShares();
		return (amountEarnedInShares);
	}
	  
}
