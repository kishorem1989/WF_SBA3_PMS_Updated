package com.javatraining.sba3.PMS_SpringBootRest.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.javatraining.sba3.PMS_SpringBootRest.Entity.RecentlyViewedCompanies;

public interface RecentlyViewedCompaniesRepository extends JpaRepository<RecentlyViewedCompanies, Long>
{
    //
}
