package com.javatraining.sba3.PMS_SpringBootRest.Entity;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class User 
{
	
	
	@Id @Column(nullable = false)
	private String username; // primary key
	
	@Column(nullable = false)
	private String password;
	
	@Column(nullable = false)
	private String usertype;
	
	@Column(nullable = false,unique = true)
	private String pan;
	
	
	public User()
	{
		
	}
	public User(String username, String password, String usertype, String pan) {
		super();
		this.username = username;
		this.password = password;
		this.usertype = usertype;
		this.pan = pan;
	}
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUsertype() {
		return usertype;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	
	
}
