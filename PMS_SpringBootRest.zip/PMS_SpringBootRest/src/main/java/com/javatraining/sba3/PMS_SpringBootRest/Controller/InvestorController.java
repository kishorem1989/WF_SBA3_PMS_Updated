package com.javatraining.sba3.PMS_SpringBootRest.Controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.CompanyOutputDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.InvestorProfileDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.StockDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.UserOutputDTO;
import com.javatraining.sba3.PMS_SpringBootRest.Service.BackofficerService;
import com.javatraining.sba3.PMS_SpringBootRest.Service.InvestorService;

@Controller
@RequestMapping("/investor")
public class InvestorController 
{
	
	@Autowired 
	private InvestorService investorservice;
	
	@Autowired 
	private BackofficerService backofficerservice;
	
	
	@GetMapping("/home-Page")
	public String investorHomePage(Model model) 
	{
		String view="";
		view = "InvestorHome";
		List<String> portfolioValues = new ArrayList<String>();
		//********************PortfolioValues*****************
		String currentPortfolioValue = this.investorservice.getCurrentPortfolioValue().toString();
		String amountInvested = this.investorservice.getAmountInvestedTillDate().toString();
		String amountEarned = this.investorservice.getAmountEarnedTillDate().toString();
		model.addAttribute("currentPortfolioValue", currentPortfolioValue);
		model.addAttribute("amountInvested", amountInvested);
		model.addAttribute("amountEarned", amountEarned);
		//****************************************************
		return view;
	}
	
	
	//********************
	// SHARES related
	//********************
	
	@GetMapping("/buy-shares") 
	public String buyShares(Model model) 
	{
		 String view="";  
		 view = "BuyShares"; 
		 List<StockDTO> allStcoks = this.backofficerservice.fetchLatestStockDetailsForEachCompany();
		 model.addAttribute("latestStockForCompany", allStcoks);
		 return view; 
	}
	
	@PostMapping("/confirm-buy-share/{companytitle}") 
	public String confirmBuyShares(@PathVariable String companytitle,@Valid @ModelAttribute("investorProfileDto") InvestorProfileDTO investorProfileDto,BindingResult result,Model model,RedirectAttributes redirectAtt) 
	{
		
		String view="";
		CompanyOutputDTO individualCompanyDetails = this.backofficerservice.fetchCompanyBasedOnTitle(companytitle.trim());
		List<StockDTO> companyStockDetails = this.backofficerservice.fetchStockBasedOnCompCode(individualCompanyDetails.getCompanycode().trim());
		model.addAttribute("individualCompany", individualCompanyDetails); // for displaying company profile table
		model.addAttribute("companyStocks", companyStockDetails.get(companyStockDetails.size()-1)); // for displaying stock related details for company
		StockDTO latestStockDetails = companyStockDetails.get(companyStockDetails.size()-1);
		if(result.hasErrors())
		{
			model.addAttribute("investorProfileDto",investorProfileDto);
			view = "IndividualCompanyProfile";
			
		}else
		{
			InvestorProfileDTO investorProfileDTO = this.investorservice.savePurchaseTransaction(investorProfileDto, individualCompanyDetails,latestStockDetails);
			redirectAtt.addFlashAttribute("HeaderMsg","You Have Successfully Purchased "+investorProfileDTO.getSharecount()+" "+investorProfileDTO.getCompanytitle().toUpperCase()+" shares");
			return "redirect:/investor/home-Page";
		}
		return view;
	}
	
	@GetMapping("/sell-shares") 
	public String sellShares(Model model) 
	{
		 String view="";  
		 view = "PurchasedShares"; 
		 List<InvestorProfileDTO> eachPurchasedCompanyShares = this.investorservice.findEachCompanyTitleForPurchasedShares();
		 model.addAttribute("eachPurchasedCompanyShares", eachPurchasedCompanyShares);
		 return view; 
	}
	
	@GetMapping("/confirm-sell-share/{companytitle}") 
	public String confirmSellShares(@PathVariable String companytitle,Model model) 
	{
		 String view="";  
		 view = "IndividualSharesPurchasedCompany"; 
		 InvestorProfileDTO investorProfileDTO = new InvestorProfileDTO();
		 model.addAttribute("investorProfileDTO", investorProfileDTO);
		 
		 List<InvestorProfileDTO> shareTransactionsForCompany = this.investorservice.findByCompanyTitle(companytitle);
		 model.addAttribute("shareTransactionsForCompany", shareTransactionsForCompany); // for all transactions for a particular company
		 
		 List<StockDTO> companyStockDetails = this.backofficerservice.fetchStockBasedOnCompCode(shareTransactionsForCompany.get(0).getCompanycode().trim());
		 model.addAttribute("companyStocks", companyStockDetails.get(companyStockDetails.size()-1)); // for displaying latest stock related details for company
		 
		 Integer sharesAvailableForCompany = this.investorservice.findAvailableShareCountForEachCompany(companytitle);
		 model.addAttribute("availableSharesCount", sharesAvailableForCompany);
		 return view; 
	}
	
	@PostMapping("/confirm-sell-share/{companytitle}") 
	public String confirmIndividualCompanySellShares(@PathVariable String companytitle,@Valid @ModelAttribute("investorProfileDTO") InvestorProfileDTO investorProfileDTO,BindingResult result,Model model,RedirectAttributes redirectAtt) 
	{
		String view="";  
		List<InvestorProfileDTO> shareTransactionsForCompany = this.investorservice.findByCompanyTitle(companytitle);
		model.addAttribute("shareTransactionsForCompany", shareTransactionsForCompany); // for all transactions for a particular company
		 
		List<StockDTO> companyStockDetails = this.backofficerservice.fetchStockBasedOnCompCode(shareTransactionsForCompany.get(0).getCompanycode().trim());
		model.addAttribute("companyStocks", companyStockDetails.get(companyStockDetails.size()-1)); // for displaying latest stock related details for company
		 
		Integer sharesAvailableForCompany = this.investorservice.findAvailableShareCountForEachCompany(companytitle);
		model.addAttribute("availableSharesCount", sharesAvailableForCompany);
		if(result.hasErrors())
		{
			model.addAttribute("investorProfileDTO",investorProfileDTO);
			view = "IndividualSharesPurchasedCompany";
				
		}else
		{
			CompanyOutputDTO companyOutputDTO = this.backofficerservice.fetchCompanyBasedOnTitle(companytitle);
			InvestorProfileDTO savedInvestorProfile = this.investorservice.saveSellingTransaction(investorProfileDTO, companyOutputDTO,companyStockDetails.get(companyStockDetails.size()-1));
			redirectAtt.addFlashAttribute("HeaderMsg","You Have Successfully Sold "+savedInvestorProfile.getSharecount()+" "+savedInvestorProfile.getCompanytitle().toUpperCase()+" shares");
			return "redirect:/investor/home-Page";
		}
		return view;
	}
	
	@GetMapping("/my-transactions") 
	public String myTransactions(Model model) 
	{
		 String view="";  
		 view = "Transactions"; 
		 List<InvestorProfileDTO> allTransactions = this.investorservice.fetchAllRecords();
		 model.addAttribute("allTransactions", allTransactions);
		 return view; 
	}
	
	
	
	//********************
	// COMPANY related
	//********************
	
	@GetMapping("/company-profile/{companytitle}")
	public String singleCompanyProfile(@PathVariable String companytitle,Model model) 
	{
		String view="";
		InvestorProfileDTO investorProfileDto = new InvestorProfileDTO();
		view = "IndividualCompanyProfile";
		CompanyOutputDTO individualCompanyDetails = this.backofficerservice.fetchCompanyBasedOnTitle(companytitle.trim());
		model.addAttribute("individualCompany", individualCompanyDetails);
		
		List<StockDTO> companyStockDetails = this.backofficerservice.fetchStockBasedOnCompCode(individualCompanyDetails.getCompanycode().trim());
		model.addAttribute("companyStocks", companyStockDetails.get(companyStockDetails.size()-1));
		model.addAttribute("investorProfileDto",investorProfileDto);
		return view;
	}
	
	@PostMapping("/search-company") 
	public String searchCompany(@RequestParam ("searchcompany") String searchCompanyTitle,Model model) 
	{
		 String view=""; 
		 if(searchCompanyTitle.trim().length()<3)
		 {
			 model.addAttribute("HeaderMsg","Please enter min 3 characters for searching company profiles");
			 view = "SearchCompany";
			 
		 }else
		 {
			 List<StockDTO> searchFoundCompanies = this.backofficerservice.findLatestStockRecordForEachCompanyTitle(searchCompanyTitle);
			 model.addAttribute("searchFoundCompanies", searchFoundCompanies);
			 view = "SearchCompany";
		 }
		 return view;  
	}
	
	@GetMapping("/search-company-profile/{companytitle}")
	public String searchCompanyProfile(@PathVariable String companytitle,Model model) 
	{
		String view="";
		InvestorProfileDTO investorProfileDto = new InvestorProfileDTO();
		view = "IndividualCompanyProfile";
		CompanyOutputDTO individualCompanyDetails = this.backofficerservice.fetchCompanyBasedOnTitle(companytitle.trim());
		model.addAttribute("individualCompany", individualCompanyDetails);
		
		List<StockDTO> companyStockDetails = this.backofficerservice.fetchStockBasedOnCompCode(individualCompanyDetails.getCompanycode().trim());
		model.addAttribute("companyStocks", companyStockDetails.get(companyStockDetails.size()-1));
		model.addAttribute("investorProfileDto",investorProfileDto);
		return view;
	}
}
