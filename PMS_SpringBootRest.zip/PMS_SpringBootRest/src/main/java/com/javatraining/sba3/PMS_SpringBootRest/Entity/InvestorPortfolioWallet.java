package com.javatraining.sba3.PMS_SpringBootRest.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class InvestorPortfolioWallet 
{
	
	  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	  private Long walletId;  
	
	  @Column(nullable = false,unique=true)
	  private String username;
	  
	  @Column(nullable = false)
	  private double walletAmount; // each selling transaction amount shud be deposited to wallet 
	  
	  
	  public InvestorPortfolioWallet()
	  {
		  
	  }
	  
	  
	  public InvestorPortfolioWallet(String username, double walletAmount)
	  {
		super();
		this.username = username;
		this.walletAmount = walletAmount;
	  }

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public double getWalletAmount() {
		return walletAmount;
	}

	public void setWalletAmount(double walletAmount) {
		this.walletAmount = walletAmount;
	}
	  
	  
}
