package com.javatraining.sba3.PMS_SpringBootRest.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class CompanyProfile 
{

	 @Id @Column(nullable = false,unique = true) 
	 private String companycode; //primary key
	 
	 @Column(nullable = false,unique=true)
	 private String companytitle;
	 
	 @Column(nullable = false)
	 private String operations;
	 
	 @Column(nullable = false)
	 private int sharecount;
	 
	 @Column(nullable = false)
	 private double openshareprice;
	 
	 @Column(nullable = false)
	 private String sector;
	 
	 @Column(nullable = false)
	 private double turnover;
	
	 public CompanyProfile()
	 {
		 
	 }
	 public CompanyProfile(String companycode, String companytitle, String operations, int sharecount,
			double openshareprice, String sector, double turnover) 
	 {
		super();
		this.companycode = companycode;
		this.companytitle = companytitle;
		this.operations = operations;
		this.sharecount = sharecount;
		this.openshareprice = openshareprice;
		this.sector = sector;
		this.turnover = turnover;
	}

	public String getCompanycode() {
		return companycode;
	}

	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}

	public String getCompanytitle() {
		return companytitle;
	}

	public void setCompanytitle(String companytitle) {
		this.companytitle = companytitle;
	}

	public String getOperations() {
		return operations;
	}

	public void setOperations(String operations) {
		this.operations = operations;
	}

	public int getSharecount() {
		return sharecount;
	}

	public void setSharecount(int sharecount) {
		this.sharecount = sharecount;
	}

	public double getOpenshareprice() {
		return openshareprice;
	}

	public void setOpenshareprice(double openshareprice) {
		this.openshareprice = openshareprice;
	}

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}
	public double getTurnover() {
		return turnover;
	}

	public void setTurnover(double turnover) {
		this.turnover = turnover;
	}
	 
	 
	 
}
