package com.javatraining.sba3.PMS_SpringBootRest.DTO;

import javax.persistence.Column;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class StockDTO 
{
	 
	 private String companycode;
	 private String companytitle;
	 
	 
	 @NotNull(message = "Stock exchange is mandatory")
	 @NotBlank(message = "Stock exchange is mandatory")
	 private String stockexchange;
	 
	 @NotNull(message = "current share price is mandatory")
	 @DecimalMin(value = "1.0",message="current share price must be greater than 1")
	 private double currentprice;
	 
	 private String asofDateAndTime;

	 
	 // getters and setters
	public String getCompanycode() {
		return companycode;
	}

	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}

	public String getCompanytitle() {
		return companytitle;
	}

	public void setCompanytitle(String companytitle) {
		this.companytitle = companytitle;
	}

	public String getStockexchange() {
		return stockexchange;
	}

	public void setStockexchange(String stockexchange) {
		this.stockexchange = stockexchange;
	}

	public double getCurrentprice() {
		return currentprice;
	}

	public void setCurrentprice(double currentprice) {
		this.currentprice = currentprice;
	}

	public String getAsofDateAndTime() {
		return asofDateAndTime;
	}

	public void setAsofDateAndTime(String asofDateAndTime) {
		this.asofDateAndTime = asofDateAndTime;
	}
	 
	 
}
