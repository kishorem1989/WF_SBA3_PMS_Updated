package com.javatraining.sba3.PMS_SpringBootRest.DTO;


import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;


public class InvestorProfileDTO 
{
 
	 
	  private String username;
	  private String companycode;
	  private String companytitle;
	  
	 
	  private double shareamount;
	  
	  @NotNull(message = "share quantity must be greater than 0")
	  @Min(value=1,message = "share quantity must be greater than 0")
	  private int sharecount;
	  
	 
	  private String transactionType; // 'purchase' ,'sell' ,'welcome bonus' - 2500
	  private String transactionDateAndTime;
	  private String currencyType; // investor shud select currency type for trading
	  private double brokerageAmount; // 2% upon selling of stocks
	  private double purchasedStockPrice; 
	  
	  
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getCompanycode() {
		return companycode;
	}
	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}
	public String getCompanytitle() {
		return companytitle;
	}
	public void setCompanytitle(String companytitle) {
		this.companytitle = companytitle;
	}
	public double getShareamount() {
		return shareamount;
	}
	public void setShareamount(double shareamount) {
		this.shareamount = shareamount;
	}
	
	public int getSharecount() {
		return sharecount;
	}
	public void setSharecount(int sharecount) {
		this.sharecount = sharecount;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionDateAndTime() {
		return transactionDateAndTime;
	}
	public void setTransactionDateAndTime(String transactionDateAndTime) {
		this.transactionDateAndTime = transactionDateAndTime;
	}
	public String getCurrencyType() {
		return currencyType;
	}
	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}
	public double getBrokerageAmount() {
		return brokerageAmount;
	}
	public void setBrokerageAmount(double brokerageAmount) {
		this.brokerageAmount = brokerageAmount;
	}
	public double getPurchasedStockPrice() {
		return purchasedStockPrice;
	}
	public void setPurchasedStockPrice(double purchasedStockPrice) {
		this.purchasedStockPrice = purchasedStockPrice;
	}
	  
	  
	
}
