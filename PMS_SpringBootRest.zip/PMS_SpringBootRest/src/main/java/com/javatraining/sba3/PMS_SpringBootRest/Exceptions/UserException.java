package com.javatraining.sba3.PMS_SpringBootRest.Exceptions;

public class UserException extends RuntimeException 
{
	public UserException(String message)
	{
		super(message);
	}
}
