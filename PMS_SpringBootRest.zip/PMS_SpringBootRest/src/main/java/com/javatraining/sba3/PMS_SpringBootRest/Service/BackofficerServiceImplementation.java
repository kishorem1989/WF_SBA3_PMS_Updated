package com.javatraining.sba3.PMS_SpringBootRest.Service;
  
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
  
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Component;

import com.javatraining.sba3.PMS_SpringBootRest.DTO.CommodityDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.CompanyInputDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.CompanyOutputDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.StockDTO;
import com.javatraining.sba3.PMS_SpringBootRest.Entity.Commodities;
import com.javatraining.sba3.PMS_SpringBootRest.Entity.CompanyProfile;
import com.javatraining.sba3.PMS_SpringBootRest.Entity.Stock;
import com.javatraining.sba3.PMS_SpringBootRest.Repository.CommodityRepository;
import com.javatraining.sba3.PMS_SpringBootRest.Repository.CompanyRepository;
import com.javatraining.sba3.PMS_SpringBootRest.Repository.StockRepository;
  

@Component 
public class BackofficerServiceImplementation implements BackofficerService
  
{
  
	  @Autowired //field based dependency 
	  private CompanyRepository companyRepository;
	  
	  
	  
	  //***************************
	  // COMPANY Related Methods
	  //***************************
	  
	  
	  private CompanyOutputDTO companyEntitytToOutputDTO(CompanyProfile company) 
	  {
		  CompanyOutputDTO companyOutputDTO = new CompanyOutputDTO();
		  companyOutputDTO.setCompanycode(company.getCompanycode());
		  companyOutputDTO.setCompanytitle(company.getCompanytitle());
		  companyOutputDTO.setOpenshareprice(company.getOpenshareprice());
		  companyOutputDTO.setOperations(company.getOperations());
		  companyOutputDTO.setSector(company.getSector());
		  companyOutputDTO.setSharecount(company.getSharecount());
		  companyOutputDTO.setTurnover(company.getTurnover()); 
		  return companyOutputDTO;
	  } 
	  
	  private CompanyProfile inputDTOToCompanyEntity(CompanyInputDTO companyInputDTO) 
	  { 
		  CompanyProfile companyProfile = new CompanyProfile();
		  companyProfile.setCompanycode(companyInputDTO.getCompanycode());
		  companyProfile.setCompanytitle(companyInputDTO.getCompanytitle());
		  companyProfile.setOpenshareprice(companyInputDTO.getOpenshareprice());
		  companyProfile.setOperations(companyInputDTO.getOperations());
		  companyProfile.setSector(companyInputDTO.getSector());
		  companyProfile.setSharecount(companyInputDTO.getSharecount());
		  companyProfile.setTurnover(companyInputDTO.getTurnover()); 
		  return companyProfile;
	  }
	  
	  //*************************
	  // CRUD Methods - Company
	  //*************************
	  
	  @Override 
	  public CompanyOutputDTO addCompany(CompanyInputDTO companyInputDTO)
	  { 
		  CompanyProfile companyProfile = this.inputDTOToCompanyEntity(companyInputDTO);
		  CompanyProfile newCompany = this.companyRepository.save(companyProfile);
		  CompanyOutputDTO companyOutputDTO = this.companyEntitytToOutputDTO(newCompany);
		  return companyOutputDTO; 
	  }
	  
	  @Override 
	  public List<CompanyOutputDTO> fetchAllCompanies() 
	  {
		  List<CompanyProfile> allCompanies = this.companyRepository.findAll();
		  List<CompanyOutputDTO> companyOutputDTOs = new ArrayList<CompanyOutputDTO>();
		  for(CompanyProfile company: allCompanies) 
		  { 
			  CompanyOutputDTO companyOutputDTO = this.companyEntitytToOutputDTO(company);
			  companyOutputDTOs.add(companyOutputDTO); 
		  } 
		  return companyOutputDTOs; 
	  }
	  
	  @Override 
	  public CompanyOutputDTO updateCompany(String companyCode,CompanyInputDTO companyInputDto) 
	  { 
		  
		  CompanyProfile companyDetails = this.companyRepository.findById(companyCode).orElse(null);
		  companyDetails.setCompanycode(companyCode);
		  companyDetails.setCompanytitle(companyInputDto.getCompanytitle());
		  companyDetails.setOpenshareprice(companyInputDto.getOpenshareprice());
		  companyDetails.setOperations(companyInputDto.getOperations());
		  companyDetails.setSector(companyInputDto.getSector());
		  companyDetails.setSharecount(companyInputDto.getSharecount());
		  companyDetails.setTurnover(companyInputDto.getTurnover());
		  CompanyProfile updatedCompanyDetails = this.companyRepository.save(companyDetails);
		  CompanyOutputDTO updatedCompany = this.companyEntitytToOutputDTO(updatedCompanyDetails);
		  return updatedCompany; 
	  }
		  
	  
	  @Override 
	  public CompanyOutputDTO fetchCompanyBasedOnCodeAndTitle(String companyCode,String companyTitle) 
	  { 
		  CompanyOutputDTO companyOutputDTO = new CompanyOutputDTO();
		  List<CompanyProfile> companyProfile = companyRepository.findByCompanycodeOrCompanytitle(companyCode,companyTitle);
		  if(companyProfile.size()>0)
		  {	
			  companyOutputDTO = this.companyEntitytToOutputDTO(companyProfile.get(0));
		  }else
		  {
			  companyOutputDTO = null;
		  }
		  return companyOutputDTO; 
	  }
	  
	  @Override 
	  public CompanyOutputDTO fetchCompanyBasedOnCode(String companyCode) 
	  { 
		  CompanyOutputDTO companyOutputDTO = new CompanyOutputDTO();
		  CompanyProfile companyProfile = this.companyRepository.findById(companyCode).orElse(null);
		  if(companyProfile==null)
		  {
			  companyOutputDTO = null;
		  }else
		  {
			  companyOutputDTO = this.companyEntitytToOutputDTO(companyProfile);
		  }
		  return companyOutputDTO; 
	  }

	@Override
	public CompanyOutputDTO fetchCompanyBasedOnTitle(String companyTitle) 
	{
		CompanyOutputDTO companyOutputDTO = new CompanyOutputDTO();
		CompanyProfile companyProfile = this.companyRepository.findByCompanytitle(companyTitle);
		if(companyProfile==null)
		  {
			  companyOutputDTO = null;
		  }else
		  {
			  companyOutputDTO = this.companyEntitytToOutputDTO(companyProfile);
		  }
		  return companyOutputDTO;
	}

	//***************************
	// STOCK Related Methods
	//***************************
	
	@Autowired //field based dependency 
	private StockRepository stockRepository;
	
	public Stock stockDTOToStockEntity(StockDTO stockDto)
	{
		Stock stock = new Stock();
		stock.setCompanycode(stockDto.getCompanycode());
		stock.setCompanytitle(stockDto.getCompanytitle());
		stock.setStockexchange(stockDto.getStockexchange());
		stock.setCurrentprice(stockDto.getCurrentprice());
		//********************************************
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss aa");  
	    Date date = new Date(); 
	    stock.setAsofDateAndTime(formatter.format(date).toString());
	    //********************************************
		//stock.setAsofDateAndTime();
		return stock;
	}
	public StockDTO stockEntityToDTO(Stock stock)
	{
		StockDTO stockDto = new StockDTO();
		stockDto.setCompanycode(stock.getCompanycode());
		stockDto.setCompanytitle(stock.getCompanytitle());
		stockDto.setStockexchange(stock.getStockexchange());
		stockDto.setCurrentprice(stock.getCurrentprice());
		stockDto.setAsofDateAndTime(stock.getAsofDateAndTime());
		return stockDto;
	}
	
	
	//*************************
	// CRUD Methods - Stock
	//*************************
	
	@Override
	public StockDTO addStockDetails(StockDTO stockDto) 
	{
		Stock stock = this.stockDTOToStockEntity(stockDto);
		Stock stockDetailsSaved = this.stockRepository.save(stock);
		StockDTO savedStockDto = this.stockEntityToDTO(stockDetailsSaved);
		return savedStockDto; 
	}

	@Override
	public List<StockDTO> fetchAllStocks() 
	{
		List<StockDTO> stockOutputDTOs = new ArrayList<StockDTO>();  
		List<Stock> allStocks = this.stockRepository.findAll();
		  for(Stock stock: allStocks) 
		  { 
			  StockDTO stockOutputDTO = this.stockEntityToDTO(stock);
			  stockOutputDTOs.add(stockOutputDTO); 
		  } 
		  return stockOutputDTOs; 
	}

	@Override
	public List<StockDTO> fetchStockBasedOnCompCode(String companyCode) 
	{
		List<StockDTO> allStocksDTOs = new ArrayList<StockDTO>();
		List<Stock> stocksBasedOnCompCode = this.stockRepository.findByCompanycode(companyCode);
		for(Stock eachStock:stocksBasedOnCompCode)
		{
			StockDTO eachStockDto = this.stockEntityToDTO(eachStock);
			allStocksDTOs.add(eachStockDto);
		}
		return allStocksDTOs;
	}

	
	@Override
	public List<StockDTO> fetchLatestStockDetailsForEachCompany() 
	{
		List<StockDTO> stockDTOs = new ArrayList<StockDTO>();
		List<Stock> allStocks = this.stockRepository.findLatestStockRecordForEachCompany();
		for(Stock eachStock:allStocks)
		{
			StockDTO eachStockDto = this.stockEntityToDTO(eachStock);
			stockDTOs.add(eachStockDto);
		}
		return stockDTOs;
	}

	@Override
	public List<StockDTO> findLatestStockRecordForEachCompanyTitle(String companytitle) 
	{
		List<StockDTO> stockDTOs = new ArrayList<StockDTO>();
		List<Stock> stockEntitys = this.stockRepository.findLatestStockRecordForEachCompanyTitle(companytitle);
		for(Stock eachStockEntitys:stockEntitys)
		{
			StockDTO eachStockDto = this.stockEntityToDTO(eachStockEntitys);
			stockDTOs.add(eachStockDto);
		}
		return stockDTOs;
	}
	
	
	//***************************
	// COMMODITY Related Methods
	//***************************
		
	@Autowired //field based dependency 
	private CommodityRepository commodityRepository;
	
	public Commodities commodityDTOToEntity(CommodityDTO commodityDTO)
	{
		Commodities commodities = new Commodities();
		commodities.setCommodityname(commodityDTO.getCommodityname());
		commodities.setCommodityprice(commodityDTO.getCommodityprice());
		//********************************************
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss aa");  
	    Date date = new Date(); 
	    commodities.setAsofDateAndTime(formatter.format(date).toString());
	    //********************************************
	    return commodities;
	}
	public CommodityDTO commodityEntityToCommodityDTO(Commodities commodities)
	{
		CommodityDTO commodityDTO = new CommodityDTO();
		commodityDTO.setCommodityname(commodities.getCommodityname());
		commodityDTO.setCommodityprice(commodities.getCommodityprice());
		commodityDTO.setAsofDateAndTime(commodities.getAsofDateAndTime());
		return commodityDTO;
	}
	
	
	
	//*************************
	// CRUD Methods - COMMODITY
	//*************************
	
	@Override
	public CommodityDTO addCommodityDetails(CommodityDTO commodityDTO) 
	{
		Commodities commodities = new Commodities();
		commodities = this.commodityDTOToEntity(commodityDTO);
		Commodities savedCommodity = this.commodityRepository.save(commodities);
		CommodityDTO savedCommodityDTO = this.commodityEntityToCommodityDTO(savedCommodity);
		return savedCommodityDTO;
	}

	@Override
	public List<CommodityDTO> fetchAllCommodities() 
	{
		List<CommodityDTO> commodityDTOs = new ArrayList<CommodityDTO>();
		List<Commodities> commodities = this.commodityRepository.findAll();
		for(Commodities eachCommodities:commodities)
		{
			CommodityDTO singleCommodityDTO = this.commodityEntityToCommodityDTO(eachCommodities);	
			commodityDTOs.add(singleCommodityDTO);
		}
		return commodityDTOs;
	}

	@Override
	public List<CommodityDTO> fetchCommodityBasedOnCommodityName(String commodityName) 
	{
		List<CommodityDTO> commodityDTOs = new ArrayList<CommodityDTO>();
		List<Commodities> commodities = this.commodityRepository.findByCommodityname(commodityName);
		for(Commodities eachCommodities:commodities)
		{
			CommodityDTO eachCommodityDTO = this.commodityEntityToCommodityDTO(eachCommodities);
			commodityDTOs.add(eachCommodityDTO);
		}
		return commodityDTOs;	
	}

	

	
	
  
  }
 