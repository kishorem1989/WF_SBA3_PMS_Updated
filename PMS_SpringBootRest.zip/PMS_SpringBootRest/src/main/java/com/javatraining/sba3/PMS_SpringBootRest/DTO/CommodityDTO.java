package com.javatraining.sba3.PMS_SpringBootRest.DTO;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class CommodityDTO 
{
	  @NotNull(message = "Commodity name is mandatory")
	  @NotBlank(message = "Commodity name is mandatory")
	  private String commodityname;
	  
	  @NotNull(message = "Commodity price is mandatory")
	  @DecimalMin(value = "1.0",message="Commodity price must be greater than 1")
	  private double commodityprice;
	  
	  private String asofDateAndTime;

	  
	  // getters and setters
	public String getCommodityname() {
		return commodityname;
	}

	public void setCommodityname(String commodityname) {
		this.commodityname = commodityname;
	}

	public double getCommodityprice() {
		return commodityprice;
	}

	public void setCommodityprice(double commodityprice) {
		this.commodityprice = commodityprice;
	}

	public String getAsofDateAndTime() {
		return asofDateAndTime;
	}

	public void setAsofDateAndTime(String asofDateAndTime) {
		this.asofDateAndTime = asofDateAndTime;
	}
	  
	  
}
