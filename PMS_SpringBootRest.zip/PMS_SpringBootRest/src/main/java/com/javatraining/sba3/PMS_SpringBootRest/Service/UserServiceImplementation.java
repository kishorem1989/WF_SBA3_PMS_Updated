package com.javatraining.sba3.PMS_SpringBootRest.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.javatraining.sba3.PMS_SpringBootRest.DTO.UserInputDTO;
import com.javatraining.sba3.PMS_SpringBootRest.DTO.UserOutputDTO;
import com.javatraining.sba3.PMS_SpringBootRest.Entity.User;
import com.javatraining.sba3.PMS_SpringBootRest.Repository.UserRepository;

@Component
public class UserServiceImplementation implements UserService 
{

	@Autowired //field based dependency 
	private UserRepository userRepository;
	
	private UserOutputDTO userEntitytToOutputDTO(User user)
	{
		UserOutputDTO userOutputDTO = new UserOutputDTO();
		userOutputDTO.setUsername(user.getUsername());
		userOutputDTO.setPassword(user.getPassword());
		userOutputDTO.setPan(user.getPan());
		userOutputDTO.setUsertype(user.getUsertype());
		return userOutputDTO;
		
	}
	private User inputDTOToUserEntity(UserInputDTO userInputDTO)
	{
		User user = new User();
		user.setUsername(userInputDTO.getUsername());
		user.setPassword(userInputDTO.getPassword());
		user.setPan(userInputDTO.getPan());
		user.setUsertype(userInputDTO.getUsertype());
		return user;
	}
	
	

	@Override
	public UserOutputDTO addUser(UserInputDTO userInputDTO) {
		
		User user = this.inputDTOToUserEntity(userInputDTO);
		User newUser = this.userRepository.save(user);
		UserOutputDTO userOutputDTO = this.userEntitytToOutputDTO(newUser);
		return userOutputDTO;
	}

	@Override
	public UserOutputDTO fetchBasedOnUserName(String username) 
	{
		
		UserOutputDTO userOutputDTO = new UserOutputDTO();
		User user = this.userRepository.findById(username).orElse(null);
		if(user==null)
		{
			userOutputDTO = null;
		}else
		{
			userOutputDTO = this.userEntitytToOutputDTO(user);
		}
		return userOutputDTO;
	}
	
	@Override
	public UserOutputDTO fetchBasedOnPAN(String pan) 
	{
		
		UserOutputDTO userOutputDTO = new UserOutputDTO();
		User user = this.userRepository.findByPan(pan);
		if(user==null)
		{
			userOutputDTO = null;
		}
		else
		{
			userOutputDTO = this.userEntitytToOutputDTO(user);
		}
		return userOutputDTO;
	}
	@Override
	public UserOutputDTO fetchBasedOnUserNameAndPassword(String username, String password) {

		UserOutputDTO userOutputDTO = new UserOutputDTO();
		User user = this.userRepository.findByUsernameAndPassword(username, password);
		if(user==null)
		{
			userOutputDTO = null;
		}
		else
		{
			userOutputDTO = this.userEntitytToOutputDTO(user);
		}
		return userOutputDTO;
	}

}
