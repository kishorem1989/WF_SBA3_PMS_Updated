package com.javatraining.sba3.PMS_SpringBootRest.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class InvestorProfile 
{

	  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	  private Long transactionId;
	  
	  @Column(nullable = false)
	  private String username;
	  
	  @Column(nullable = false)
	  private String companycode;
	  
	  @Column(nullable = false)
	  private String companytitle;
	  
	  @Column(nullable = false)
	  private double shareamount;
	  
	  @Column(nullable = false)
	  private int sharecount;
	  
	  @Column(nullable = false)
	  private String transactionType; // 'purchase' ,'sell' ,'welcome bonus' - 2500
	  
	  @Column(nullable = false)
	  private String transactionDateAndTime;
	  
	  @Column(nullable = false)
	  private String currencyType; // investor shud select currency type for trading
	  
	  @Column(nullable = false)
	  private double brokerageAmount; // 2% upon selling of stocks
	
	  @Column(nullable = false)
	  private double purchasedStockPrice; 
	  
	  public InvestorProfile()
	  {
		  
	  }



	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}

	public String getCompanycode() {
		return companycode;
	}


	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}


	public String getCompanytitle() {
		return companytitle;
	}


	public void setCompanytitle(String companytitle) {
		this.companytitle = companytitle;
	}


	public double getShareamount() {
		return shareamount;
	}


	public void setShareamount(double shareamount) {
		this.shareamount = shareamount;
	}


	public int getSharecount() {
		return sharecount;
	}


	public void setSharecount(int sharecount) {
		this.sharecount = sharecount;
	}


	public String getTransactionType() {
		return transactionType;
	}


	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}


	public String getTransactionDateAndTime() {
		return transactionDateAndTime;
	}


	public void setTransactionDateAndTime(String transactionDateAndTime) {
		this.transactionDateAndTime = transactionDateAndTime;
	}


	public String getCurrencyType() {
		return currencyType;
	}


	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}


	public double getBrokerageAmount() {
		return brokerageAmount;
	}


	public void setBrokerageAmount(double brokerageAmount) {
		this.brokerageAmount = brokerageAmount;
	}



	public double getPurchasedStockPrice() {
		return purchasedStockPrice;
	}

	public void setPurchasedStockPrice(double purchasedStockPrice) {
		this.purchasedStockPrice = purchasedStockPrice;
	}
	  

		
	  
}
